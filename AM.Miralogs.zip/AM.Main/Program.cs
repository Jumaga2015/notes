﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using AM.Logs;

namespace AM.Main
{
    class Program
    {
        static DateTime _ahora;
        static void Main(string[] args)
        {
            _ahora = DateTime.Now;

            CriteriaIndex criteriaIndex = new CriteriaIndex() { Pattern = @"Orden: (?'orden'000\d{7})", ValuePattern = @"${orden}" };

            string pathtofile = Globals.Path + "file.log";
            string filesPath = @"C:\Users\jumag\Documents\Source\Avanade\Miralogs\Data\file*.log";
            FileInfo fi = new FileInfo(pathtofile);

            FileLogInfo fli = new FileLogInfo(pathtofile, fi.CreationTime, fi.LastWriteTime, fi.Length, filesPath);

            var logFile = new LogFile(pathtofile, fli,  criteriaIndex, CancellationToken.None);
            logFile.ProgressUpdate += Leerarchivo_ProgressUpdate;
            logFile.Complete += Leerarchivo_Complete;
            logFile.Error += LogFile_Error;
            Task t = logFile.Do();

            t.Wait();
            Console.WriteLine("Indexacion:" + (DateTime.Now- _ahora).ToString());

            CriteriaSearch criteriaSearch = new CriteriaSearch() { IndexPattern = "0004444444", Pattern = "Op:3030", MathType = MatchType.SubStringCaseInsensitive, ScanType = ScanType.None };
            logFile.Buscar(criteriaSearch);

            Console.WriteLine("Busqueda Directa:" + (DateTime.Now - _ahora).ToString());

            criteriaSearch = new CriteriaSearch() { IndexPattern = "0004444444", Pattern = "Op:3010", MathType = MatchType.SubStringCaseInsensitive, ScanType = ScanType.LineasUpDn, Times = 2 };
            logFile.Buscar(criteriaSearch);

            Console.WriteLine("BusquedaLineaUpDn:" + (DateTime.Now - _ahora).ToString());

            //_ahora = DateTime.Now;
            //int line = -1;
            //Regex regexIndex = new Regex(criteriaIndex.Pattern, RegexOptions.Compiled);
            //foreach (var l in logFile.Lineas)
            //{
            //    line++;
            //    string contenido = logFile.GetLine(line);
            //    //"Orden: 000\d{7}"g
            //    Match match = regexIndex.Match(contenido);
            //    if (match != Match.Empty)
            //        Console.WriteLine($"Line:{logFile.GetLine(line)} Value:{regexIndex.Replace(contenido, criteriaIndex.ValuePattern)} Tiempo:" + (DateTime.Now - _ahora).ToString());
            //}
            //Console.WriteLine($"TiempoIndexar:" + (DateTime.Now - _ahora).ToString());



            //LeerArchivo leerarchivo = new LeerArchivo(@"..\..\..\Data\filegrande.log", CancellationToken.None);
            //leerarchivo.ProgressUpdate += Leerarchivo_ProgressUpdate;
            //leerarchivo.Complete += Leerarchivo_Complete;
            //_ahora = DateTime.Now;
            //Task task = leerarchivo.Do();

            //task.Wait();

            Console.ReadKey();
        }

        private static void LogFile_Error(object sender, Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }

        private static void Leerarchivo_Complete(object sender, TimeSpan e)
        {
            Console.WriteLine($"Leerarchivo_Completed: tiempo:" + e.ToString());
        }

        private static void Leerarchivo_ProgressUpdate(object sender, int e)
        {
            Console.WriteLine($"Leerarchivo_ProgressUpdate: prc:" + e);
        }

    }
}
