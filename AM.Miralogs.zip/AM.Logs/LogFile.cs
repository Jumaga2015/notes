﻿using AM.Utilidades;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace AM.Logs
{
    public partial class LogFile : Tarea
    {
        private readonly int MAXFILEIOBUFFER = 1024 * 1024;
        private readonly int MAXLINEBUFFER = 1024 * 1;

        #region Member Variables
        public Searches Searches { get; set; }
        [JsonIgnore] public List<LogLine> Lineas { get; private set; } = new List<LogLine>();

        public int LineCount { get; private set; } = 0;

        private FileStream fileStream;
        private CriteriaIndex criteriaIndex;

        Regex regexIndex;

        public string FileName { get; private set; }
        public string FileCacheName { get; private set; }
        [JsonIgnore] public FileLogInfo FileLogInfo { get; private set; }
        public List<ushort> FilterIds { get; private set; } = new List<ushort>();
        public string Guid { get; private set; }
        private DateTime TimespanPrimero { get; set; } = DateTime.MaxValue;
        private DateTime TimespanUltimo { get; set; } = DateTime.MinValue;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        public LogFile(string filePath, FileLogInfo fileLogInfo, CriteriaIndex criteriaIndex, CancellationToken ct) : base(ct)
        {
            this.Guid = System.Guid.NewGuid().ToString();
            this.FileName = filePath;
            this.criteriaIndex = criteriaIndex;

            regexIndex = new Regex(criteriaIndex.Pattern, RegexOptions.Compiled);  //Preparamos el regex

            FileLogInfo = fileLogInfo;
            logTimespanCurrent = fileLogInfo.CreationTime;

            FileCacheName = LogFile.GenerateHash(FileLogInfo.FullPath + criteriaIndex.Pattern + criteriaIndex.ValuePattern) + ".bin";

            this.Searches = new Searches();
        }

        public override void TareaImplementacion()
        {
            string fullPath = Path.Combine(Globals.PathCaches, FileCacheName);
            var posInicial = LeerCache(fullPath);

            // Indexar el fichero con la posición inicial
            Indexar(posInicial);

            FileLogInfo.TotalLines = LineCount;
            GrabarCache(FileCacheName, fullPath);
        }

        private long LeerCache(string fullPath)
        {
            int lineCount = 0;
            long posInicial = 0;
            if (File.Exists(fullPath))
            {
                using (BinaryReader reader = new BinaryReader(File.Open(fullPath, FileMode.Open)))
                {
                    while (reader.BaseStream.Position != reader.BaseStream.Length)
                    {
                        DateTime logTimespan = new DateTime(reader.ReadInt64());
                        int identationLevel = reader.ReadInt32();
                        long offset = reader.ReadInt64();
                        int charCount = reader.ReadInt32();
                        // Leer los valores de IndexMatches del fichero binario, primero la cantidad de valores
                        int count = reader.ReadInt32();
                        List<string> lista = new List<string>(count);
                        while (count-- > 0)
                            lista.Add(reader.ReadString());

                        Lineas.Add(new LogLine()
                        {
                            LineNumber = lineCount++, //Linea de la lista
                            LogTimespan = logTimespan,
                            Offset = offset,
                            CharCount = charCount,
                            IndentationLevel = identationLevel,
                            IndexMatches = lista,
                            IsIndexLine = true,
                            IsCacheLine = true
                        });
                        posInicial = offset + charCount;
                    }
                }
            }

            return posInicial;
        }

        private void GrabarCache(string filename, string fullPath)
        {
            //Grabar en un fichero binario las lineas indexadas para poder cargarlas en memoria después
            string path = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            filename = Path.Combine(path, filename);

            //Grabar el fichero binario se puede optimizar para no grabar las lineas en blanco o contenido en blanco.
            using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Append)))  //Abrirlo en modo append y grabar al final
            {
                foreach (LogLine logLine in this.Lineas.Where(l => !l.IsCacheLine))
                {
                    writer.Write(logLine.LogTimespan.Ticks);
                    writer.Write(logLine.IndentationLevel);
                    writer.Write(logLine.Offset);
                    writer.Write(logLine.CharCount);
                    // Escribir los valores de IndexMatches en el fichero binario, primero la cantidad de valores
                    writer.Write(logLine.IndexMatches.Count);
                    foreach (string s in logLine.IndexMatches)
                        writer.Write(s);
                }
            }
        }

        private bool Indexar(long posInicial)
        {
            this.Dispose();

            bool error = false;
            try
            {
                byte[] tempBufferFile = new byte[MAXFILEIOBUFFER];
                long chunkOffset = 0;        //Offset del chunk actual

                byte[] workBufferLine = new byte[MAXLINEBUFFER];
                int workIndexLine = 0;         //Indice de la linea actual;

                this.fileStream = new FileStream(FileName, FileMode.Open, FileAccess.Read);

                long position = posInicial;    // Posición global del fichero de log
                long lineStartOffset = 0;      // Posición inicio de la linea
                int numBytesRead = 0;

                string tempLine = string.Empty; // buffer temporal de la linea
                
                //Nos posicionamos con lo venga en posInicial
                fileStream.Seek(position, SeekOrigin.Begin); //Nos posicionamos al principio del fichero
                while (position < this.fileStream.Length)
                {
                    numBytesRead = this.fileStream.Read(tempBufferFile, 0, MAXFILEIOBUFFER);
                    chunkOffset = 0;

                    for (int i = 0; i < numBytesRead; i++)
                    {
                        byte b = tempBufferFile[i];

                        if (b == '\r')
                        {
                            position++;
                            continue;
                        }
                        if (b == '\n')
                        {
                            LogLine linelog = AddLineTimespan(workBufferLine, lineStartOffset, workIndexLine);

                            position++;
                            workIndexLine = 0;           //Reinicializamos el puntero del line de trabajo
                            lineStartOffset = position;  //La siguiente linea empieza en esta posicion

                            //Procesar indexado
                            List<string> matches = AddIndexValue(workBufferLine, linelog.CharCount);
                            if (matches != null && matches.Count > 0)
                            {
                                linelog.IndexMatches = matches;
                                linelog.IsIndexLine = true;
                            }
                            continue;
                        }
                        workBufferLine[workIndexLine] = b;

                        workIndexLine++;
                        position++;
                        chunkOffset++;

                        // Actualizamos el progreso cada 10% del fichero
                        if (position % (FileLogInfo.Length / 10) == 0)
                        {
                            OnProgressUpdate((int)((double)position / (double)FileLogInfo.Length * 100));

                            if (cancellationToken.IsCancellationRequested)
                            {
                                return false;
                            }
                        }
                    }

                } // While
            }
            catch (IOException exception)
            {
                OnLoadError(exception);
                error = true;
            }
            finally
            {
                if (error == false)
                {
                    OnProgressUpdate(100);
                }
            }
            return true;
        }

        /// <summary>
        /// Marca la linea perteneciente a un Index
        /// </summary>
        /// <param name="workBufferLine"></param>
        /// <param name="charCount"></param>
        /// <returns></returns>
        private List<string> AddIndexValue(byte[] workBufferLine, int charCount)
        {
            //variable temporal a retornar  
            List<string> result = new List<string>();

            var tempLine = Encoding.ASCII.GetString(workBufferLine, 0, charCount);

            MatchCollection matches = regexIndex.Matches(tempLine);
            foreach (var m in matches)
            {
                result.Add(regexIndex.Replace(m.ToString(), criteriaIndex.ValuePattern));
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            this.fileStream?.Dispose();
        }

        //Implementación de Buscar que devuelva un Task
        public Task<List<int>> BuscarAsync(CriteriaSearch sc)
        {
            return Task.Run(() => Buscar(sc));
        }

        public List<int> Buscar(CriteriaSearch sc)
        {
            string fullPath = Path.Combine(Globals.PathCaches, FileCacheName);
            var posInicial = LeerCache(fullPath);
            se si va aqui

            DateTime start = DateTime.Now;
            List<int> results = new List<int>();

            OnProgressUpdate(0);

            //Localizamos las lineas que coinciden
            IEnumerable<LogLine> linesIndex = Lineas.Where(i => i.IsIndexLine)
                .Where(i => i.IndexMatches.Contains(sc.IndexPattern));

            foreach (LogLine ll in linesIndex)
            {
                int lineIndex = 0;

                switch (sc.ScanType)
                {
                    case ScanType.None:
                        string buffer = GetLine(ll.LineNumber);
                        if (BuscarEnLinea(sc, buffer))
                        {
                            ll.IsContextLine = true;
                            results.Add(ll.LineNumber);
                        }
                        break;
                    case ScanType.Indentacion:
                        //Buscamos en las lineas anteriores hasta que no tengan indentacion
                        lineIndex = ll.LineNumber;
                        while (lineIndex > 0)
                        {
                            lineIndex--;
                            if (Lineas[lineIndex].IndentationLevel == 0)
                                break;
                            buffer = GetLine(lineIndex);
                            if (BuscarEnLinea(sc, buffer))
                            {
                                ll.IsContextLine = true;
                                results.Add(ll.LineNumber);
                            }
                        }
                        //Buscamos en las lineas posteriores hasta que no tengan indentacion
                        lineIndex = ll.LineNumber;
                        while (lineIndex < Lineas.Count)
                        {
                            lineIndex++;
                            if (Lineas[lineIndex].IndentationLevel == 0)
                                break;
                            buffer = GetLine(lineIndex);
                            if (BuscarEnLinea(sc, buffer))
                            {
                                ll.IsContextLine = true;
                                results.Add(ll.LineNumber);
                            }
                        }
                        break;
                    case ScanType.LineasUpDn:
                    case ScanType.LineasUp:
                    case ScanType.LineasDn:
                        lineIndex = ll.LineNumber;

                        //Buscamos en las lineas anteriores hasta que no tengan indentacion
                        if (sc.ScanType == ScanType.LineasUpDn || sc.ScanType == ScanType.LineasUp)
                        {
                            while (lineIndex > 0 && lineIndex > ll.LineNumber - sc.Times)
                            {
                                lineIndex--;
                                buffer = GetLine(lineIndex);
                                if (BuscarEnLinea(sc, buffer))
                                {
                                    ll.IsContextLine = true;
                                    results.Add(ll.LineNumber);
                                }
                            }
                        }
                        //Buscamos en las lineas posteriores hasta que no tengan indentacion
                        if (sc.ScanType == ScanType.LineasUpDn || sc.ScanType == ScanType.LineasDn)
                        {
                            while (lineIndex < Lineas.Count && lineIndex < ll.LineNumber + sc.Times)
                            {
                                lineIndex++;
                                buffer = GetLine(lineIndex);
                                if (BuscarEnLinea(sc, buffer))
                                {
                                    ll.IsContextLine = true;
                                    results.Add(ll.LineNumber);
                                }
                            }
                        }
                        break;
                    case ScanType.MinutosUpDn:
                    case ScanType.MinutosUp:
                    case ScanType.MinutosDn:
                        lineIndex = ll.LineNumber;
                        //Buscamos en las lineas anteriores si esta dentro del rango de minutos atrás
                        if (sc.ScanType == ScanType.MinutosUpDn || sc.ScanType == ScanType.MinutosUp)
                        {
                            while (lineIndex > 0)
                            {
                                lineIndex--;
                                if (Lineas[lineIndex].LogTimespan < ll.LogTimespan.AddMinutes(-sc.Times))
                                    break;
                                buffer = GetLine(lineIndex);
                                if (BuscarEnLinea(sc, buffer))
                                {
                                    ll.IsContextLine = true;
                                    results.Add(ll.LineNumber);
                                }
                            }
                        }
                        //Buscamos en las lineas posteriores si está dentro del rango de minutos delante
                        if (sc.ScanType == ScanType.MinutosUpDn || sc.ScanType == ScanType.MinutosDn)
                        {
                            while (lineIndex < Lineas.Count)
                            {
                                lineIndex++;
                                if (Lineas[lineIndex].LogTimespan > ll.LogTimespan.AddMinutes(sc.Times))
                                    break;
                                buffer = GetLine(lineIndex);
                                if (BuscarEnLinea(sc, buffer))
                                {
                                    ll.IsContextLine = true;
                                    results.Add(ll.LineNumber);
                                }
                            }
                        }
                        break;
                }
            }
            OnProgressUpdate(100);
            return results;
        }

        // Lee el fichero para cargar el contenido de la linea y comparar.
        private bool BuscarEnLinea(CriteriaSearch sc, string buffer)
        {
            switch (sc.MathType)
            //Tipo de busqueda dentro de la linea
            {
                case MatchType.SubStringCaseInsensitive:
                    if (buffer.IndexOf(sc.Pattern, 0, StringComparison.OrdinalIgnoreCase) > -1)
                    {
                        return true;
                    }
                    break;
                case MatchType.SubStringCaseSensitive:
                    if (buffer.IndexOf(sc.Pattern, 0, StringComparison.Ordinal) > -1)
                    {
                        return true;
                    }
                    break;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchText"></param>
        /// <param name="searchType"></param>
        //public Task SearchMulti(List<CriteriaSearch> scs, CancellationToken ct)
        //{
        //    return new Task(() => {

        //        DateTime start = DateTime.Now;
        //        bool cancelled = false;
        //        long matches = 0;
        //        try
        //        {
        //            long counter = 0;
        //            string line = string.Empty;
        //            bool located = false;

        //            foreach (LogLine ll in this.Lineas)
        //            {
        //                // Reset the match flag
        //                ll.SearchMatches.Clear();

        //                foreach (CriteriaSearch sc in scs)
        //                {
        //                    line = this.GetLine(ll.LineNumber);

        //                    located = false;
        //                    switch (sc.Type)
        //                    {
        //                        case SearchType.SubStringCaseInsensitive:
        //                            if (line.IndexOf(sc.Pattern, 0, StringComparison.OrdinalIgnoreCase) > -1)
        //                            {
        //                                located = true;
        //                            }
        //                            break;

        //                        case SearchType.SubStringCaseSensitive:
        //                            if (line.IndexOf(sc.Pattern, 0, StringComparison.Ordinal) > -1)
        //                            {
        //                                located = true;
        //                            }
        //                            break;

        //                        case SearchType.RegexCaseInsensitive:
        //                            if (Regex.Match(line, sc.Pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled) != Match.Empty)
        //                            {
        //                                located = true;
        //                            }
        //                            break;

        //                        case SearchType.RegexCaseSensitive:
        //                            if (Regex.Match(line, sc.Pattern, RegexOptions.Compiled) != Match.Empty)
        //                            {
        //                                located = true;
        //                            }
        //                            break;

        //                        default:
        //                            break;
        //                    }

        //                    if (located == true)
        //                    {
        //                        matches++;
        //                        ll.SearchMatches.Add(sc.Id);
        //                    }
        //                }

        //                if (counter++ % 50 == 0)puedo optener 
        //                {
        //                    OnProgressUpdate((int)((double)counter / (double)this.Lineas.Count * 100));

        //                    if (ct.IsCancellationRequested)
        //                    {
        //                        cancelled = true;
        //                        return;
        //                    }
        //                }
        //            }
        //        }
        //        finally
        //        {
        //            DateTime end = DateTime.Now;

        //            OnProgressUpdate(100);
        //            OnSearchComplete(end - start, matches, scs.Count, cancelled);
        //        }
        //    });
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="ct"></param>
        //public void Export(string filePath, CancellationToken ct)
        //{
        //    this.ExportToFile(this.Lineas, filePath, ct);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lines"></param>
        /// <param name="filePath"></param>
        /// <param name="ct"></param>
        //public void Export(IEnumerable lines, string filePath, CancellationToken ct)
        //{
        //    this.ExportToFile(lines, filePath, ct);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="ct"></param>
        //private void ExportToFile(IEnumerable lines, string filePath, CancellationToken ct)
        //{
        //    Task.Run(() =>
        //    {
        //        DateTime start = DateTime.Now;
        //        bool cancelled = false;
        //        try
        //        {
        //            using (FileStream fs = new FileStream(filePath, FileMode.Create))
        //            {
        //                string lineStr = string.Empty;
        //                byte[] lineBytes;
        //                byte[] endLine = new byte[2] { 13, 10 };

        //                long counter = 0;
        //                foreach (LogLine ll in lines)
        //                {
        //                    lineStr = this.GetLine(ll.LineNumber);
        //                    lineBytes = Encoding.ASCII.GetBytes(lineStr);
        //                    fs.Write(lineBytes, 0, lineBytes.Length);
        //                    // Add \r\n
        //                    fs.Write(endLine, 0, 2);

        //                    if (counter++ % 50 == 0)
        //                    {
        //                        OnProgressUpdate((int)((double)counter / (double)Lineas.Count * 100));

        //                        if (ct.IsCancellationRequested)
        //                        {
        //                            cancelled = true;
        //                            return;
        //                        }
        //                    }
        //                }

        //            }
        //        }
        //        finally
        //        {
        //            DateTime end = DateTime.Now;

        //            OnProgressUpdate(100);
        //            OnExportComplete(end - start, cancelled);
        //        }
        //    });
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="charCount"></param>
        private void AddLine(long offset, int charCount)
        {
            LogLine linea = new LogLine();
            linea.Offset = offset;
            linea.CharCount = charCount;
            linea.LineNumber = this.LineCount;
            this.Lineas.Add(linea);
            this.LineCount++;
        }


        private DateTime logTimespanCurrent; //Ultima fecha parseada.
        // ^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})   regex for Datetime
        private string logThreadCurrent;  //TODO: Parsear thread y guardar
        private LogLine AddLineTimespan(byte[] buffer, long offset, int charCount)
        {
            //string debug = System.Text.Encoding.Default.GetString(line, 0, charCount);

            LogLine linea = new LogLine();
            linea.Offset = offset;
            linea.CharCount = charCount;
            linea.LineNumber = this.LineCount;
            linea.IndentationLevel = ParseIndentationLevel(buffer, charCount);
            logTimespanCurrent = ParseTimespan(0, buffer, charCount, logTimespanCurrent);
            linea.LogTimespan = logTimespanCurrent;

            this.Lineas.Add(linea);

            if (TimespanPrimero > linea.LogTimespan) TimespanPrimero = logTimespanCurrent;
            if (TimespanUltimo < linea.LogTimespan) TimespanUltimo = logTimespanCurrent;

            this.LineCount++;

            return linea;
        }

        private int ParseIndentationLevel(byte[] buffer, int charCount)
        {
            int level = 0;
            for (int i = 0; i < charCount; i++)
            {
                if (buffer[i] == ' ') level++;
                else break;
            }
            return level;
        }

        private DateTime ParseTimespan(long offset, byte[] buffer, int chartCount, DateTime defaultdt)
        {
            if (chartCount < UtilesASCCI.FormatDateTime.Length) return defaultdt; //No es fecha

            //yyyy-MM-dd HH-mm-ss,fff
            //0    5  8  11 14 17 20
            //    4  7  10 13 16 19
            if (buffer[offset + 4] != UtilesASCCI.FormatDateTime[4]) return defaultdt; //No es fecha
            //int year = 1000 * (line[offset+0]-'0') + 100 * (line[offset+1]-'0') + 10 * (line[offset+2]-'0') + (line[offset+3] - '0');
            int year = 1000 * buffer[offset + 0] + 100 * buffer[offset + 1] + 10 * buffer[offset + 2] + buffer[offset + 3] - UtilesASCCI.Digitos4;

            if (buffer[offset + 7] != UtilesASCCI.FormatDateTime[7]) return defaultdt;
            int month = 10 * buffer[offset + 5] + buffer[offset + 6] - UtilesASCCI.Digitos2;

            if (buffer[offset + 10] != UtilesASCCI.FormatDateTime[10]) return defaultdt;
            int day = 10 * buffer[offset + 8] + buffer[offset + 9] - UtilesASCCI.Digitos2;

            if (buffer[offset + 13] != UtilesASCCI.FormatDateTime[13]) return defaultdt;
            int hour = 10 * buffer[offset + 11] + buffer[offset + 12] - UtilesASCCI.Digitos2;

            if (buffer[offset + 16] != UtilesASCCI.FormatDateTime[16]) return defaultdt;
            int minute = 10 * buffer[offset + 14] + buffer[offset + 15] - UtilesASCCI.Digitos2;

            if (buffer[offset + 19] != UtilesASCCI.FormatDateTime[19]) return defaultdt;
            int second = 10 * buffer[offset + 17] + buffer[offset + 18] - UtilesASCCI.Digitos2;

            DateTime value = new DateTime(year, month, day, hour, minute, second, DateTimeKind.Utc);

            // Add sub-seconds (no ctor to pass with other parts)
            int subseconds = 100 * buffer[offset + 20] + 10 * buffer[offset + 21] + buffer[offset + 22] - UtilesASCCI.Digitos3;
            value = value.AddTicks(subseconds);

            return value;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="lineNumber"></param>
        /// <returns></returns>
        public string GetLine(int lineNumber)
        {
            if (lineNumber >= this.Lineas.Count)
            {
                return string.Empty;
            }

            byte[] buffer = new byte[this.Lineas[lineNumber].CharCount + 1];
            try
            {
                //lock (this)
                {
                    this.fileStream.Seek(this.Lineas[lineNumber].Offset, SeekOrigin.Begin);
                    this.fileStream.Read(buffer, 0, this.Lineas[lineNumber].CharCount);
                }
            }
            catch (Exception) { }

            //return Regex.Replace(Encoding.ASCII.GetString(line), "[\0-\b\n\v\f\x000E-\x001F\x007F-ÿ]", "", RegexOptions.Compiled);
            return Encoding.ASCII.GetString(buffer);
        }

        #region Event Methods
        /// <summary>
        /// 
        /// </summary>
        private void OnLoadError(Exception exception)
        {
            ErrorTarea(exception);
        }

        /// <summary>
        /// 
        /// </summary>
        private void OnProgressUpdate(int progress)
        {
            ProgresoTarea(progress);
        }
        #endregion
    }
}


