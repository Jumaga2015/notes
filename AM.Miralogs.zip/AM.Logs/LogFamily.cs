﻿using AM.Logs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM.Logs
{
    //LogFamily mantiene los ficheros que cumplen el filtro dado
    public class LogFamily
    {
        string PathFamily { get; set; }
        public List<FileLogInfo> FilesInSystem { get; private set; }  //Ficheros que cumplen el filtro y las fechas y sin tratar
        public Dictionary<string, FileLogInfo> Files { get; private set; }  //Fichero verificados

        public LogFamily(string filtroFiles)
        {
            PathFamily = filtroFiles;
            FilesInSystem = this.GetFilesInfo(filtroFiles);
            Files = new Dictionary<string, FileLogInfo>();
        }

        /// <summary>
        /// Fichero verificado añadido
        /// </summary>
        /// <param name="file"></param>
        public void AddFile(FileLogInfo file)
        {
            Files.Add(file.Key, file);
        }

        //Devuelve los ficheros del sistema que cumplen el filtro dado en el sistema de ficheros
        private List<FileLogInfo> GetFilesInfo(string filtroFiles)
        {
            List<FileInfo> files = this.GetFiles(filtroFiles).ToList();

           return files.Select(f => new FileLogInfo(f.FullName, f.CreationTime, f.LastWriteTime, f.Length, filtroFiles))
                .ToList();
        }

        private List<FileInfo> GetFiles(string filtroFiles)
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetDirectoryName(filtroFiles));
            return directoryInfo.GetFiles(Path.GetFileName(filtroFiles)).ToList();
        }

        //Comprobamos si el fichero existe o existia y cambio de nombre o crece
        public (FileLogInfo, bool) ValidarFile(FileLogInfo fileLogInfo)
        {
            FileLogInfo actualfileLogInfo = FilesInSystem.Where(f => f.CreationTime == fileLogInfo.CreationTime).FirstOrDefault();
            
            if (actualfileLogInfo==null) //No existe el fichero lo marcamos invalido
                return (null, false);

            //Si el fichero existe y está indexado comprobamos si ha cambiado
            if (fileLogInfo.IsIndexed)
            {
                if (actualfileLogInfo.Length > fileLogInfo.Length)
                {
                    actualfileLogInfo.IsIndexed = false;
                    actualfileLogInfo.IsSemiIndexed = true; //El fichero ha crecido se puede aprovechar lo ya indexado
                    return (actualfileLogInfo, false);
                }
                return (actualfileLogInfo, true);
            }

            return (actualfileLogInfo, false);
           
        }
    }
}
