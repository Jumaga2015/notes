﻿namespace AM.Logs
{
    public static class Globals
    {
        public static readonly string Path = @"..\..\..\Data\";
        public static readonly string PathCaches = Path + "Caches";
    }
}
