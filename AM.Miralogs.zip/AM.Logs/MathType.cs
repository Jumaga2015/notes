﻿namespace AM.Logs
{
    public enum MatchType
    {
        SubStringCaseInsensitive = 0,
        SubStringCaseSensitive = 1,
        RegexCaseInsensitive = 2,
        RegexCaseSensitive = 3,
    }
}


