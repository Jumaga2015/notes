﻿using System;
using System.Collections.Generic;

namespace AM.Logs
{
    public class LogLine
    {
        public int LineNumber { get; set; } = 0;
        public long Offset { get; set; } = 0;
        public int CharCount { get; set; } = 0;
        public DateTime LogTimespan { get; set; }
        public string LogThread { get; set; }
        public int IndentationLevel { get; internal set; }
        public List<string> IndexMatches { get; set; } = new List<string>();
        public List<ushort> SearchMatches { get; set; } = new List<ushort>();
        public bool IsCacheLine { get; set; } = false;
        public bool IsIndexLine { get; set; } = false;
        public bool IsContextLine { get; set; } = false;
    }

}


