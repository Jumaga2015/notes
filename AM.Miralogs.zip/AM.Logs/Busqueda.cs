﻿using JsonFlatFileDataStore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AM.Logs
{
    public class Busqueda
    {
        public event EventHandler<FileLogInfo> FileFound;
        public event EventHandler<FileLogInfo> FileChanged;

        public string Id { get; set; }  //Nombre
        public string Filtro { get; set; }
        public DateTime Desde { get; set; }
        public DateTime Hasta { get; set; }
        private CriteriaIndex IndexCriteria { get; set; }
        public CriteriaSearch SearchCriteria { get; set; }

        private Dictionary<string, List<FileLogInfo>> valuesInFiles;

        private LogFamily logFamily;  //Logs en la busqueda cumpliendo el filtro y las fechas
        private DataStore store; //Base de datos 

        private CancellationTokenSource cts;

        //Generar un constructor basado en la clase BusquedaInfo




        public Busqueda(string id, string filtroFiles, DateTime desde, DateTime hasta, CriteriaIndex ci, CriteriaSearch cs)
        {
            Id = id;
            cts = new CancellationTokenSource();

            Filtro = filtroFiles;
            Desde = desde;
            Hasta = hasta;

            logFamily = new LogFamily(Filtro);

            // Open database (create new if file doesn't exist)
            store = new DataStore($"{Globals.Path}{Id}_DB.json", keyProperty: "Key");
            IndexCriteria = ci;
            SearchCriteria = cs;

        }

        public void Do()
        {
            IDocumentCollection<FileLogInfo> collectionFiles = store.GetCollection<FileLogInfo>();

            //lista de keys para borrar y updatar
            List<string> keysToDelete = new List<string>();
            List<FileLogInfo> keysToUpdate = new List<FileLogInfo>();

            //comprobamos si los ficheros existen y si los actualizamos
            foreach (FileLogInfo fileLogInfo in collectionFiles.AsQueryable())
            {
                (FileLogInfo actualFileLogInfo, bool valido) = logFamily.ValidarFile(fileLogInfo);
                {
                    if (!valido)
                    {
                        if (actualFileLogInfo == null)
                        {
                            //añade en una lista temporal las key para borrarlas
                            keysToDelete.Add(fileLogInfo.Key);
                        }
                        else
                            //añade en una lista temporal las key para actualizarlas
                            keysToUpdate.Add(fileLogInfo);
                    }
                }
            }

            //Borramos los ficheros que no existen
            foreach (string key in keysToDelete)
            {
                collectionFiles.DeleteOne(key);
            }

             //Actualizamos los ficheros que han cambiado
             foreach (FileLogInfo file in keysToUpdate)
            {
                collectionFiles.UpdateOne(file.Key, file);
            }


            //Filtramos por fecha los ficheros del sistema de ficheros que no queremos mirar
            List<FileLogInfo> FilesInSystemFiltrados = logFamily.FilesInSystem.Where(f => f.CreationTime >= Desde && f.LastWriteTime <= Hasta).ToList();

            //Miramos uno a uno los ficheros del sistema de ficheros para ver si están en la DB, los indexamos si no lo están y los añadimos a la familia de logs
            foreach (var fileloginfo in FilesInSystemFiltrados)
            {
                var file = collectionFiles.AsQueryable().Where(f => f.Key == fileloginfo.Key).FirstOrDefault();
                //Comprobamos si está ya indexado
                if (file != null && file.IsIndexed)
                {
                    logFamily.AddFile(file);  //Lo agregamos a la familia de logs para poder buscar en ellos
                    OnFileFound(file);  //Informamos de los ficheros encontrados
                }
                else
                {
                    OnFileFound(fileloginfo);  //Informamos de los ficheros encontrados
                    if (Indexar(fileloginfo))
                    {
                        collectionFiles.InsertOne(fileloginfo);
                        OnFileChanged(file);
                    }
                }
            }

            //Seleccionamos los ficheros que cumplen el criterio de busqueda por fecha de collectionFiles
            var files = collectionFiles.AsQueryable().Where(f => f.IsIndexed && f.CreationTime >= Desde && f.CreationTime <= Hasta).ToList();
            foreach (var file in files)
            {


                logFamily.Files[file.Key].LogFile.Buscar(SearchCriteria);
            }

        }

        private bool Indexar(FileLogInfo fileLogInfo)
        {
            fileLogInfo.SetLogFile(this.IndexCriteria, cts.Token);

            var task = fileLogInfo.LogFile.Do();   //Indexamos el fichero
            task.Wait();
            if (task.IsCompleted)
            {
                fileLogInfo.IsIndexed = true;
                return true;
                
            }

            return false;
        }

        protected virtual void OnFileFound(FileLogInfo file)
        {
            FileFound?.Invoke(this, file);
        }

        protected virtual void OnFileChanged(FileLogInfo file)
        {
            FileChanged?.Invoke(this, file);
        }


    }


}
