﻿namespace AM.Logs
{
    public enum ScanType
    {
        None = 0,
        LineasUp = 1,
        LineasDn = 2,
        LineasUpDn = 3,
        Indentacion = 4,
        MinutosUp = 5,
        MinutosDn = 6,
        MinutosUpDn = 7,
    }
}


