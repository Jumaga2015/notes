﻿using System.Security.Cryptography;
using System.Text;

namespace AM.Logs
{
    public partial class LogFile
    {
        internal static class UtilesASCCI {
            internal static int Digitos4 = 53328;  // 48000+4800+480+48
            internal static int Digitos3 = 5328;   // 4800+480+48
            internal static int Digitos2 = 528;    // 480+48
            internal static int Digitos1 = 48;

            internal static byte[] FormatDateTime = Encoding.ASCII.GetBytes("yyyy-MM-dd HH:mm:ss,fff");
        }

        public static string GenerateHash(string data)
        {
            byte[] hashValue;

            using (SHA256 sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(Encoding.UTF8.GetBytes(data));
            }

            StringBuilder sb = new StringBuilder();
            foreach (byte x in hashValue)
                sb.Append(x.ToString("x2"));

            return sb.ToString();
        }

    }
}


