﻿namespace AM.Logs
{
    public class CriteriaIndex
    {
        public bool Enabled { get; set; } = true;
        public ushort Id { get; set; } = 0;
       
        public string Pattern { get; set; } = "";
        public string ValuePattern { get; set; } = "";
       
        public long Matches { get; set; } = 0;
    }
}


