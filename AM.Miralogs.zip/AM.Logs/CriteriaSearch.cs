﻿namespace AM.Logs
{
    public class CriteriaSearch
    {
        public bool Enabled { get; set; } = true;
        public ushort Id { get; set; } = 0;
        public MatchType MathType { get; set; }
        public ScanType ScanType { get; set; }
        public string IndexPattern { get; set; } = "";  // Valor de la busqueda en el indice
        public string Pattern { get; set; } = "";  //Valor de la busqueda en el log
        public long Matches { get; set; } = 0;
        public int Times { get; set; } = 0; // Según el tipo de scan este valor se evalua (up,dn, updn)
    }

    
}


