﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Runtime.Remoting.Messaging;
using Newtonsoft.Json;

namespace AM.Logs
{
    public class FileLogInfo
    {
        public string FullPath { get; private set; }
        public string FileName { get; private set; }
        public string InvariantName { get; private set; }
        public string Extension { get; private set; }
        public DateTime CreationTime { get; private set; }
        public DateTime LastWriteTime { get; private set; }
        public long Length { get; set; } = 0;
        public bool IsIndexed { get; set; } = false;
        [JsonIgnore] public bool IsSemiIndexed { get; set; } = false;

        [JsonIgnore] public LogFile LogFile { get; private set; }
                
        public string Key => InvariantName + CreationTime.ToString("yyyyMMdd|HHmmss|fffffff") + Extension.Replace(".", "|");

        public int TotalLines { get; internal set; }

        [JsonConstructor] public FileLogInfo(string fullPath,
                                             string fileName,
                                             string invariantName,
                                             string extension,
                                             DateTime creationTime,
                                             DateTime lastWriteTime,
                                             bool isIndexed,
                                             long length)
        {
            FullPath = fullPath;
            FileName = fileName;
            InvariantName = invariantName;
            Extension = extension;
            CreationTime = creationTime;
            LastWriteTime = lastWriteTime;
            IsIndexed = isIndexed;
            Length = length;
        }

        public FileLogInfo(string fullPath, DateTime creationTime, DateTime lastWriteTime, long length, string searchPath)
        {
            FullPath = fullPath;
            FileName = Path.GetFileName(fullPath);
            Extension = Path.GetExtension(searchPath);

            InvariantName = GetValidFilename(fullPath, searchPath);
            CreationTime = creationTime;
            LastWriteTime = lastWriteTime;
            this.Length = length;
        }

        public void SetLogFile(CriteriaIndex ci, CancellationToken ct)
        {
            LogFile = new LogFile(FullPath, this, ci, ct);
        }

        //Setea el nombre univoco del fichero de log
        private string GetValidFilename(string fullPath, string searchPath)
        {
            var invariantName = Path.GetFileNameWithoutExtension(searchPath);
            foreach (char c in System.IO.Path.GetInvalidFileNameChars())
            {
                invariantName = invariantName.Replace(c, '_');
            }
            return invariantName;
        }
    }
}
