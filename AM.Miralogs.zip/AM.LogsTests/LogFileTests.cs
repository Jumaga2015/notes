﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AM.logs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM.logs.Tests
{
    [TestClass()]
    public class LogFileTests
    {
        [TestMethod()]
        public void ParseTimespanFromBufferTest()  //TODO: Varios test
        {
            Assert.Fail();
        }
    }
}