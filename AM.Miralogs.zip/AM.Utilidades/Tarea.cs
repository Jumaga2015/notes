﻿using Newtonsoft.Json;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AM.Utilidades
{
    public abstract class Tarea
    {
        //Un datetime para medir el tiempo de ejecución de la tarea.
        
        [JsonIgnore] public DateTime Antes { get; set; }

        // Evento para notificar el progreso de la tarea.
        public event EventHandler<int> ProgressUpdate;
        // Evento para notificar un error en la tarea.
        public event EventHandler<Exception> Error;
        // Evento para notificar la finalización de la tarea.
        public event EventHandler<TimeSpan> Complete;
        // Evento para notificar la cancelación de la tarea.
        public event EventHandler<TimeSpan> Cancel;

        // Token de cancelación para permitir que la tarea sea cancelada.
        protected CancellationTokenSource cancellationToken;

        // Task para almacenar la tarea en segundo plano.
        [JsonIgnore] public Task Task { get; private set; }

        // Constructor para inicializar el token de cancelación.
        public Tarea(CancellationToken cancellationToken)
        {
            this.cancellationToken = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        }

        // Método abstracto que implementa la lógica de la tarea larga.
        public abstract void TareaImplementacion();

        // Método que crea e inicia la tarea en segundo plano.
        public Task Do()
        {
            progresoAnterior = int.MinValue; 
            DateTime antes = DateTime.Now;

            Task = Task.Run(() =>
            {
                try
                {
                    ProgresoTarea(0);
                    // Llamar al método abstracto que implementa la lógica de la tarea.
                    TareaImplementacion();

                    //Notificar la finalización de la tarea y el tiempo que tardó en ejecutarse.
                    ProgresoTarea(100);
                    Complete?.Invoke(this, DateTime.Now-antes);
                }
                catch (OperationCanceledException)
                {
                    // La tarea fue cancelada, enviar un evento de cancelación con el tiempo de duración.
                    Cancel?.Invoke(this, DateTime.Now - antes);
                }
                catch (Exception ex)
                {
                    // Notificar un error si la tarea lanza una excepción.
                    Error?.Invoke(this, ex);
                }
            }, cancellationToken.Token);

            return Task;
        }

        // Método que cancela la tarea.
        public void CancelarTarea()
        {
            // Si el token de cancelación no ha sido cancelado anteriormente, cancelarlo ahora.
            if (!cancellationToken.IsCancellationRequested)
            {
                cancellationToken.Cancel();
            }
        }

        int progresoAnterior = int.MinValue; 
        // Método que actualiza el progreso de la tarea en porcentage, controla el cancelationtoken.
        public void ProgresoTarea(int progreso)
        {
            if (progresoAnterior== progreso) return; 
            progresoAnterior = progreso;
            cancellationToken.Token.ThrowIfCancellationRequested();
            ProgressUpdate?.Invoke(this, progresoAnterior);
        }

        public void ErrorTarea(Exception exception) {
            Error?.Invoke(this, exception);
        }


    }
}
